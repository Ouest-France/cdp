package fr.ouestfrance;

import com.arakelian.docker.junit.DockerRule;

import static org.junit.Assert.assertTrue;

import org.junit.ClassRule;
import org.junit.Test;

import static com.arakelian.docker.junit.model.ImmutableDockerConfig.builder;

public class DockerTest {

    @ClassRule
    public static DockerRule container = new DockerRule(builder()
            .name("redis")
            .image("redis:4-alpine")
            .ports("6379").build());

    @Test
    public void test1() {
        assertTrue(container.getContainer().getPort("6379/tcp") > 0);
    }
    
}
